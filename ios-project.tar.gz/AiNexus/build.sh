#!/bin/bash
# AI Nexus iOS Build Script
# Run on macOS with Xcode installed

set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLATFORM_DIR="$PROJECT_DIR/platforms/ios"

echo "=== AI Nexus iOS Build ==="
echo "Project: $PROJECT_DIR"

# Step 1: Install npm dependencies
echo "[1/5] Installing npm dependencies..."
cd "$PROJECT_DIR"
npm install

# Step 2: Prepare iOS platform
echo "[2/5] Preparing iOS platform..."
npx cordova prepare ios

# Step 3: Build with Xcode (Archive)
echo "[3/5] Building with Xcode..."
cd "$PLATFORM_DIR"

# Clean first
xcodebuild clean \
    -workspace "App.xcworkspace" \
    -scheme "App" \
    -configuration Release

# Archive
xcodebuild archive \
    -workspace "App.xcworkspace" \
    -scheme "App" \
    -configuration Release \
    -archivePath "$PROJECT_DIR/output/AI_Nexus.xcarchive" \
    CODE_SIGN_IDENTITY="" \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGNING_ALLOWED=NO

# Step 4: Export IPA from archive
echo "[4/5] Exporting IPA..."
mkdir -p "$PROJECT_DIR/output/Payload"
cp -R "$PROJECT_DIR/output/AI_Nexus.xcarchive/Products/Applications/AI Nexus.app" \
    "$PROJECT_DIR/output/Payload/"

cd "$PROJECT_DIR/output"
zip -r "AI_Nexus.ipa" Payload/
rm -rf Payload/

# Step 5: Done
echo "[5/5] Build complete!"
echo "IPA: $PROJECT_DIR/output/AI_Nexus.ipa"
echo ""
echo "=== SIGNING INSTRUCTIONS ==="
echo "This IPA is unsigned. To sign it:"
echo "1. For personal device testing: Use AltStore / Sideloadly"
echo "2. For distribution: Use a signing service (udid.tech, app.iosappsigner.com, etc.)"
echo "3. With Apple Developer account: codesign + xcrun altool"
